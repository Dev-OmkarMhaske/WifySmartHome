package com.wify.smart.home.dto;

public class MiniserverObject {

    private String ip;
    private String mac;
    private String state;
    private String flag;

    public MiniserverObject(String ip, String mac, String state) {
        this.ip = ip;
        this.mac = mac;
        this.state = state;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
